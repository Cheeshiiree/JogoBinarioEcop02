
#ifndef STDIO_H
#define	STDIO_H

void printf(char msg[34]);

#endif	/* STDIO_H */

